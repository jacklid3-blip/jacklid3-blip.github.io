/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
// Name: Jack Lidsterr
// Date: January 13, 2026
// App name: JavaApplication3
// Description: Student Info Program

import java.text.MessageFormat;

// Constants
final String CLEAR_TERMINAL = "\033c";
final String SET_TITLE = "\033]0;{0}\007";
final String BANNER = """
                                    ==============================
                                    -    Welcome to Durham!      -
                                    ==============================
                                    """;

/**
 * Your Java code starts and ends here!
 */
void main() {
    // Set the title
    IO.print(MessageFormat.format(SET_TITLE, "student - Jack Lidsterr"));
    
    // Declare username
    IO.println(BANNER);
    String fullname = IO.readln("Enter your name: ");
    String programName = IO.readln("Enter program name: ");
    int Semester = Integer.parseInt(IO.readln("total semesters in program: "));
    int currentsemester = Integer.parseInt(IO.readln("Enter current semester: "));
    // processing
    int semestersRemaining = Semester - currentsemester;
    // output
    IO.println(CLEAR_TERMINAL);
    IO.println(BANNER);
    IO.println("Student Name: " + fullname);
    IO.println("Program Name: " + programName);
    IO.println("Semesters Remaining: " + semestersRemaining);
    // Exit prompt - So the terminal doesn't close in our faces!
    IO.readln("\nPress [enter] to exit: ");
}